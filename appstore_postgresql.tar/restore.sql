--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE appstore;
--
-- Name: appstore; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE appstore WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE appstore OWNER TO postgres;

\connect appstore

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: apps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apps (
    app_id integer NOT NULL,
    app_name text,
    category text,
    size_in_mb integer,
    installs text,
    rating integer,
    reviews integer,
    app_version text,
    last_updated timestamp without time zone
);


ALTER TABLE public.apps OWNER TO postgres;

--
-- Data for Name: apps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apps (app_id, app_name, category, size_in_mb, installs, rating, reviews, app_version, last_updated) FROM stdin;
\.
COPY public.apps (app_id, app_name, category, size_in_mb, installs, rating, reviews, app_version, last_updated) FROM '$$PATH$$/2981.dat';

--
-- Name: apps app_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT app_id_pk PRIMARY KEY (app_id);


--
-- PostgreSQL database dump complete
--

