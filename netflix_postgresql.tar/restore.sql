--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE netflix;
--
-- Name: netflix; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE netflix WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE netflix OWNER TO postgres;

\connect netflix

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: movies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movies (
    title text,
    director text,
    "cast" text,
    country text,
    date_added timestamp without time zone,
    release_year bigint,
    rating text,
    listed_in text,
    description text,
    duration_in_minutes bigint
);


ALTER TABLE public.movies OWNER TO postgres;

--
-- Name: series; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.series (
    title text,
    director text,
    "cast" text,
    country text,
    date_added timestamp without time zone,
    release_year bigint,
    rating text,
    listed_in text,
    description text,
    num_of_seasons bigint
);


ALTER TABLE public.series OWNER TO postgres;

--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movies (title, director, "cast", country, date_added, release_year, rating, listed_in, description, duration_in_minutes) FROM stdin;
\.
COPY public.movies (title, director, "cast", country, date_added, release_year, rating, listed_in, description, duration_in_minutes) FROM '$$PATH$$/2984.dat';

--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.series (title, director, "cast", country, date_added, release_year, rating, listed_in, description, num_of_seasons) FROM stdin;
\.
COPY public.series (title, director, "cast", country, date_added, release_year, rating, listed_in, description, num_of_seasons) FROM '$$PATH$$/2985.dat';

--
-- PostgreSQL database dump complete
--

