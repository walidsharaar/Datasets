--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE playcenter;
--
-- Name: playcenter; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE playcenter WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE playcenter OWNER TO postgres;

\connect playcenter

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    player_id integer NOT NULL,
    first_name text,
    last_name text,
    email_address text,
    gender text,
    age_group text,
    country text,
    city text,
    preferred_language text,
    street_address text,
    amount_spent_usd double precision,
    total_playing_minutes integer,
    installed_games integer,
    uninstalled_games integer
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (player_id, first_name, last_name, email_address, gender, age_group, country, city, preferred_language, street_address, amount_spent_usd, total_playing_minutes, installed_games, uninstalled_games) FROM stdin;
\.
COPY public.players (player_id, first_name, last_name, email_address, gender, age_group, country, city, preferred_language, street_address, amount_spent_usd, total_playing_minutes, installed_games, uninstalled_games) FROM '$$PATH$$/2981.dat';

--
-- Name: players player_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT player_id_pk PRIMARY KEY (player_id);


--
-- PostgreSQL database dump complete
--

