--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE students_survey;
--
-- Name: students_survey; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE students_survey WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE students_survey OWNER TO postgres;

\connect students_survey

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.survey (
    survey_id integer NOT NULL,
    survey_date text,
    student_id integer,
    full_name text,
    academic_major text,
    university_id integer,
    age integer,
    height_cm integer,
    location_type text,
    family_size text,
    parents_status text,
    mother_job text,
    father_job text,
    in_relationship text
);


ALTER TABLE public.survey OWNER TO postgres;

--
-- Data for Name: survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.survey (survey_id, survey_date, student_id, full_name, academic_major, university_id, age, height_cm, location_type, family_size, parents_status, mother_job, father_job, in_relationship) FROM stdin;
\.
COPY public.survey (survey_id, survey_date, student_id, full_name, academic_major, university_id, age, height_cm, location_type, family_size, parents_status, mother_job, father_job, in_relationship) FROM '$$PATH$$/2981.dat';

--
-- Name: survey survey_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.survey
    ADD CONSTRAINT survey_id_pk PRIMARY KEY (survey_id);


--
-- PostgreSQL database dump complete
--

