--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE job_adverts;
--
-- Name: job_adverts; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE job_adverts WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE job_adverts OWNER TO postgres;

\connect job_adverts

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    job_id bigint NOT NULL,
    job_title text,
    published_date timestamp without time zone,
    removed_date timestamp without time zone,
    company_name text,
    company_rank double precision,
    state_of_company text,
    headquarters_of_company text,
    company_market_value integer,
    salary_estimate_min text,
    salary_estimate_max text,
    company_size_min text,
    company_size_max text
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (job_id, job_title, published_date, removed_date, company_name, company_rank, state_of_company, headquarters_of_company, company_market_value, salary_estimate_min, salary_estimate_max, company_size_min, company_size_max) FROM stdin;
\.
COPY public.jobs (job_id, job_title, published_date, removed_date, company_name, company_rank, state_of_company, headquarters_of_company, company_market_value, salary_estimate_min, salary_estimate_max, company_size_min, company_size_max) FROM '$$PATH$$/2981.dat';

--
-- Name: jobs job_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT job_id_pk PRIMARY KEY (job_id);


--
-- PostgreSQL database dump complete
--

