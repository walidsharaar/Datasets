--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bookreview;
--
-- Name: bookreview; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bookreview WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE bookreview OWNER TO postgres;

\connect bookreview

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: authors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authors (
    author_id integer NOT NULL,
    authors text
);


ALTER TABLE public.authors OWNER TO postgres;

--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    book_id integer NOT NULL,
    title text,
    author_id integer,
    language_code integer,
    num_pages integer,
    publication_date timestamp without time zone,
    publisher_id integer
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: genders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genders (
    gender_id integer NOT NULL,
    gender text
);


ALTER TABLE public.genders OWNER TO postgres;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.languages (
    language_code integer NOT NULL,
    language_name text
);


ALTER TABLE public.languages OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    location_id integer NOT NULL,
    country text,
    city text
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: occupations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.occupations (
    occupation_id integer NOT NULL,
    occupation_name text
);


ALTER TABLE public.occupations OWNER TO postgres;

--
-- Name: publishers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publishers (
    publisher_id integer NOT NULL,
    publisher_name text
);


ALTER TABLE public.publishers OWNER TO postgres;

--
-- Name: ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ratings (
    rating_id integer NOT NULL,
    book_id integer,
    user_id integer,
    rating integer,
    rating_date timestamp without time zone
);


ALTER TABLE public.ratings OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    first_name text,
    last_name text,
    email text,
    birthdate timestamp without time zone,
    occupation_id integer,
    gender_id integer,
    location_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authors (author_id, authors) FROM stdin;
\.
COPY public.authors (author_id, authors) FROM '$$PATH$$/3044.dat';

--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (book_id, title, author_id, language_code, num_pages, publication_date, publisher_id) FROM stdin;
\.
COPY public.books (book_id, title, author_id, language_code, num_pages, publication_date, publisher_id) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: genders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genders (gender_id, gender) FROM stdin;
\.
COPY public.genders (gender_id, gender) FROM '$$PATH$$/3046.dat';

--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.languages (language_code, language_name) FROM stdin;
\.
COPY public.languages (language_code, language_name) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (location_id, country, city) FROM stdin;
\.
COPY public.locations (location_id, country, city) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: occupations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.occupations (occupation_id, occupation_name) FROM stdin;
\.
COPY public.occupations (occupation_id, occupation_name) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: publishers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publishers (publisher_id, publisher_name) FROM stdin;
\.
COPY public.publishers (publisher_id, publisher_name) FROM '$$PATH$$/3050.dat';

--
-- Data for Name: ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ratings (rating_id, book_id, user_id, rating, rating_date) FROM stdin;
\.
COPY public.ratings (rating_id, book_id, user_id, rating, rating_date) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, first_name, last_name, email, birthdate, occupation_id, gender_id, location_id) FROM stdin;
\.
COPY public.users (user_id, first_name, last_name, email, birthdate, occupation_id, gender_id, location_id) FROM '$$PATH$$/3052.dat';

--
-- Name: authors author_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT author_id_pk PRIMARY KEY (author_id);


--
-- Name: books book_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT book_id_pk PRIMARY KEY (book_id);


--
-- Name: genders gender_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genders
    ADD CONSTRAINT gender_id_pk PRIMARY KEY (gender_id);


--
-- Name: languages language_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT language_id_pk PRIMARY KEY (language_code);


--
-- Name: locations location_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT location_id_pk PRIMARY KEY (location_id);


--
-- Name: occupations occupation_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.occupations
    ADD CONSTRAINT occupation_id_pk PRIMARY KEY (occupation_id);


--
-- Name: publishers publisher_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publishers
    ADD CONSTRAINT publisher_id_pk PRIMARY KEY (publisher_id);


--
-- Name: ratings rating_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT rating_id_pk PRIMARY KEY (rating_id);


--
-- Name: users user_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT user_id_pk PRIMARY KEY (user_id);


--
-- Name: books author_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT author_id_fk FOREIGN KEY (author_id) REFERENCES public.authors(author_id);


--
-- Name: ratings book_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT book_id_fk FOREIGN KEY (book_id) REFERENCES public.books(book_id);


--
-- Name: users gender_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT gender_id_fk FOREIGN KEY (gender_id) REFERENCES public.genders(gender_id);


--
-- Name: books language_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT language_id_fk FOREIGN KEY (language_code) REFERENCES public.languages(language_code);


--
-- Name: users location_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT location_id_fk FOREIGN KEY (location_id) REFERENCES public.locations(location_id);


--
-- Name: users occupation_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT occupation_id_fk FOREIGN KEY (occupation_id) REFERENCES public.occupations(occupation_id);


--
-- Name: books publisher_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT publisher_id_fk FOREIGN KEY (publisher_id) REFERENCES public.publishers(publisher_id);


--
-- Name: ratings user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT user_id_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

