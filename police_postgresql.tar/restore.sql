--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE police;
--
-- Name: police; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE police WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE police OWNER TO postgres;

\connect police

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cops; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cops (
    badge character(7) NOT NULL,
    full_name character varying(50) DEFAULT NULL::character varying,
    station_id integer,
    rank_id character(2) DEFAULT NULL::bpchar,
    superior_id character(7) DEFAULT NULL::bpchar
);


ALTER TABLE public.cops OWNER TO postgres;

--
-- Name: ranks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ranks (
    rank_id character(2) NOT NULL,
    rank_title character varying(50) DEFAULT NULL::character varying,
    base_salary integer
);


ALTER TABLE public.ranks OWNER TO postgres;

--
-- Name: stations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stations (
    station_id integer NOT NULL,
    city character varying(50) DEFAULT NULL::character varying,
    manpower integer
);


ALTER TABLE public.stations OWNER TO postgres;

--
-- Data for Name: cops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cops (badge, full_name, station_id, rank_id, superior_id) FROM stdin;
\.
COPY public.cops (badge, full_name, station_id, rank_id, superior_id) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: ranks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ranks (rank_id, rank_title, base_salary) FROM stdin;
\.
COPY public.ranks (rank_id, rank_title, base_salary) FROM '$$PATH$$/2997.dat';

--
-- Data for Name: stations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stations (station_id, city, manpower) FROM stdin;
\.
COPY public.stations (station_id, city, manpower) FROM '$$PATH$$/2998.dat';

--
-- Name: cops cops_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cops
    ADD CONSTRAINT cops_pkey PRIMARY KEY (badge);


--
-- Name: ranks ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ranks
    ADD CONSTRAINT ranks_pkey PRIMARY KEY (rank_id);


--
-- Name: stations stations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_pkey PRIMARY KEY (station_id);


--
-- PostgreSQL database dump complete
--

