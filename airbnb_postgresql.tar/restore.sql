--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE airbnb;
--
-- Name: airbnb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE airbnb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE airbnb OWNER TO postgres;

\connect airbnb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    host_id integer,
    host_name text,
    neighbourhood_group text,
    neighbourhood text,
    room_type text,
    price integer,
    price_range text,
    number_of_reviews integer,
    number_of_reviews_range text,
    minimum_nights integer,
    reviews_per_month integer
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, host_id, host_name, neighbourhood_group, neighbourhood, room_type, price, price_range, number_of_reviews, number_of_reviews_range, minimum_nights, reviews_per_month) FROM stdin;
\.
COPY public.rooms (id, host_id, host_name, neighbourhood_group, neighbourhood, room_type, price, price_range, number_of_reviews, number_of_reviews_range, minimum_nights, reviews_per_month) FROM '$$PATH$$/2981.dat';

--
-- Name: rooms rooms_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_id_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

