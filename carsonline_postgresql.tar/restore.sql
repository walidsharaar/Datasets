--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE carsonline;
--
-- Name: carsonline; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE carsonline WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE carsonline OWNER TO postgres;

\connect carsonline

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: car_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.car_types (
    car_type_id integer NOT NULL,
    car_make text,
    car_model text,
    car_year integer
);


ALTER TABLE public.car_types OWNER TO postgres;

--
-- Name: cars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cars (
    car_id integer NOT NULL,
    price integer,
    car_type_id integer,
    transmission_type_id integer,
    fuel_type_id integer
);


ALTER TABLE public.cars OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    first_name text,
    last_name text,
    email text,
    street_address text,
    phone_number text,
    birth_date timestamp without time zone,
    gender_code integer,
    location_code integer
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: fuel_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fuel_types (
    fuel_type_id integer NOT NULL,
    fuel_type_name text
);


ALTER TABLE public.fuel_types OWNER TO postgres;

--
-- Name: genders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genders (
    gender_code integer NOT NULL,
    gender text
);


ALTER TABLE public.genders OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    location_code integer NOT NULL,
    country text,
    city text
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    sale_id integer NOT NULL,
    car_id integer,
    customer_id integer,
    purchase_date timestamp without time zone
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: transmission_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transmission_types (
    transmission_type_id integer NOT NULL,
    transmission_name text
);


ALTER TABLE public.transmission_types OWNER TO postgres;

--
-- Data for Name: car_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.car_types (car_type_id, car_make, car_model, car_year) FROM stdin;
\.
COPY public.car_types (car_type_id, car_make, car_model, car_year) FROM '$$PATH$$/3035.dat';

--
-- Data for Name: cars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cars (car_id, price, car_type_id, transmission_type_id, fuel_type_id) FROM stdin;
\.
COPY public.cars (car_id, price, car_type_id, transmission_type_id, fuel_type_id) FROM '$$PATH$$/3036.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, first_name, last_name, email, street_address, phone_number, birth_date, gender_code, location_code) FROM stdin;
\.
COPY public.customers (customer_id, first_name, last_name, email, street_address, phone_number, birth_date, gender_code, location_code) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: fuel_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fuel_types (fuel_type_id, fuel_type_name) FROM stdin;
\.
COPY public.fuel_types (fuel_type_id, fuel_type_name) FROM '$$PATH$$/3038.dat';

--
-- Data for Name: genders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genders (gender_code, gender) FROM stdin;
\.
COPY public.genders (gender_code, gender) FROM '$$PATH$$/3039.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (location_code, country, city) FROM stdin;
\.
COPY public.locations (location_code, country, city) FROM '$$PATH$$/3040.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (sale_id, car_id, customer_id, purchase_date) FROM stdin;
\.
COPY public.sales (sale_id, car_id, customer_id, purchase_date) FROM '$$PATH$$/3041.dat';

--
-- Data for Name: transmission_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transmission_types (transmission_type_id, transmission_name) FROM stdin;
\.
COPY public.transmission_types (transmission_type_id, transmission_name) FROM '$$PATH$$/3042.dat';

--
-- Name: cars car_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT car_id_pk PRIMARY KEY (car_id);


--
-- Name: car_types car_type_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.car_types
    ADD CONSTRAINT car_type_id_pk PRIMARY KEY (car_type_id);


--
-- Name: customers customer_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customer_id_pk PRIMARY KEY (customer_id);


--
-- Name: fuel_types fuel_type_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fuel_types
    ADD CONSTRAINT fuel_type_id_pk PRIMARY KEY (fuel_type_id);


--
-- Name: genders gender_code_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genders
    ADD CONSTRAINT gender_code_pk PRIMARY KEY (gender_code);


--
-- Name: locations location_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT location_id_pk PRIMARY KEY (location_code);


--
-- Name: sales sale_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sale_id_pk PRIMARY KEY (sale_id);


--
-- Name: transmission_types transmission_type_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transmission_types
    ADD CONSTRAINT transmission_type_pk PRIMARY KEY (transmission_type_id);


--
-- Name: sales car_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT car_id_fk FOREIGN KEY (car_id) REFERENCES public.cars(car_id);


--
-- Name: cars car_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT car_type_fk FOREIGN KEY (car_type_id) REFERENCES public.car_types(car_type_id);


--
-- Name: sales customer_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT customer_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- Name: cars fuel_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT fuel_type_fk FOREIGN KEY (fuel_type_id) REFERENCES public.fuel_types(fuel_type_id);


--
-- Name: customers gender_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT gender_fk FOREIGN KEY (gender_code) REFERENCES public.genders(gender_code);


--
-- Name: customers location_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT location_id_fk FOREIGN KEY (location_code) REFERENCES public.locations(location_code);


--
-- Name: cars transmission_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cars
    ADD CONSTRAINT transmission_type_fk FOREIGN KEY (transmission_type_id) REFERENCES public.transmission_types(transmission_type_id);


--
-- PostgreSQL database dump complete
--

