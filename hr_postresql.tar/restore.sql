--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hr;
--
-- Name: hr; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hr WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE hr OWNER TO postgres;

\connect hr

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    first_name text,
    last_name text,
    gender text,
    country text,
    city text,
    marital_status text,
    phone_number text,
    hire_date timestamp without time zone,
    birth_date timestamp without time zone,
    job_title text,
    salary integer,
    department_id text,
    manager_id integer,
    division_name text
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, first_name, last_name, gender, country, city, marital_status, phone_number, hire_date, birth_date, job_title, salary, department_id, manager_id, division_name) FROM stdin;
\.
COPY public.employees (id, first_name, last_name, gender, country, city, marital_status, phone_number, hire_date, birth_date, job_title, salary, department_id, manager_id, division_name) FROM '$$PATH$$/2981.dat';

--
-- Name: employees emp_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT emp_id_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

