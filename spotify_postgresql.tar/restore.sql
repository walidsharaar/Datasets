--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE spotify;
--
-- Name: spotify; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE spotify WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Israel.1252';


ALTER DATABASE spotify OWNER TO postgres;

\connect spotify

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tracks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracks (
    track_id integer NOT NULL,
    title text,
    artist text,
    genre text,
    release_year integer,
    danceability integer,
    duration integer,
    popularity integer
);


ALTER TABLE public.tracks OWNER TO postgres;

--
-- Data for Name: tracks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tracks (track_id, title, artist, genre, release_year, danceability, duration, popularity) FROM stdin;
\.
COPY public.tracks (track_id, title, artist, genre, release_year, danceability, duration, popularity) FROM '$$PATH$$/2981.dat';

--
-- Name: tracks track_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT track_id_pk PRIMARY KEY (track_id);


--
-- PostgreSQL database dump complete
--

